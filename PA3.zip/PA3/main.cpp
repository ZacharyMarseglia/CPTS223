/*******************************************************************************************
* Programmer: Zachary Marseglia
* Class: CptS 223, Spring 2025
* Programming Assignment: PA3
* Date: February 27, 2025
* Description: This program implements an AVL tree-based map (`avl_map<Key, Value>`) 
* and compares its performance to the standard `std::map<Key, Value>`. It reads ZIP code 
* data from a CSV file and stores it in both data structures for benchmarking.
*******************************************************************************************/
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <chrono>
#include <random>
#include <algorithm>
#include <cctype>

#include "avl.h"
#include "city.h"

using namespace std;

string trim(const string &s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == string::npos)
        return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

string removeQuotes(string s) {
    s = trim(s);
    if (s.size() >= 3 &&
        static_cast<unsigned char>(s[0]) == 0xEF &&
        static_cast<unsigned char>(s[1]) == 0xBB &&
        static_cast<unsigned char>(s[2]) == 0xBF) {
        s = s.substr(3);
        s = trim(s);
    }
    if (!s.empty() && s.front() == '"' && s.back() == '"') {
        s = s.substr(1, s.size() - 2);
    }
    return s;
}

bool isNumber(const string &s) {
    return !s.empty() && all_of(s.begin(), s.end(), ::isdigit);
}

int main() {
    string filename = "uszips.csv";
    ifstream file(filename);
    if (!file.is_open()){
        cerr << "Error opening file: " << filename << endl;
        return 1;
    }
    
    avl_map<int, USCity> myAVLMap;
    map<int, USCity> mySTLMap;
    list<int> zipList;
    
    string line;
    getline(file, line);
    
    while(getline(file, line)) {
        if (line.empty())
            continue;
        stringstream ss(line);
        string token;
        
        getline(ss, token, ',');
        token = removeQuotes(token);
        if (token.empty()) {
            cerr << "Empty ZIP token. Skipping line." << endl;
            continue;
        }
        if (!isNumber(token)) {
            cerr << "Non-numeric ZIP token: [" << token << "]. Skipping line." << endl;
            continue;
        }
        int zip = stoi(token);
        
        getline(ss, token, ',');
        getline(ss, token, ',');
        string city;
        getline(ss, city, ',');
        city = removeQuotes(city);
        getline(ss, token, ',');
        string state;
        getline(ss, state, ',');
        state = removeQuotes(state);
        string zipType;
        getline(ss, zipType, ',');
        zipType = removeQuotes(zipType);
        getline(ss, token, ',');
        getline(ss, token, ',');
        getline(ss, token, ',');
        getline(ss, token, ',');
        string county;
        getline(ss, county, ',');
        county = removeQuotes(county);
        for (int i = 0; i < 5; i++) {
            getline(ss, token, ',');
        }
        string tz;
        getline(ss, tz, ',');
        tz = removeQuotes(tz);
        
        USCity cityData(city, state, county, zipType, tz);
        myAVLMap.insert(zip, cityData);
        mySTLMap.insert({zip, cityData});
        zipList.push_back(zip);
    }
    file.close();
    
    cout << "CSV parsed and maps populated." << endl;
    
    size_t numLookups = 1000;
    vector<int> zipVec(zipList.begin(), zipList.end());
    random_device rd;
    mt19937 g(rd());
    shuffle(zipVec.begin(), zipVec.end(), g);
    
    vector<int> lookupZips;
    for (size_t i = 0; i < numLookups && i < zipVec.size(); ++i) {
        lookupZips.push_back(zipVec[i]);
    }
    
    auto startAVL = chrono::high_resolution_clock::now();
    for (int zip : lookupZips) {
        myAVLMap.find(zip);
    }
    auto endAVL = chrono::high_resolution_clock::now();
    auto durationAVL = chrono::duration_cast<chrono::microseconds>(endAVL - startAVL).count();
    
    auto startSTL = chrono::high_resolution_clock::now();
    for (int zip : lookupZips) {
        mySTLMap.find(zip);
    }
    auto endSTL = chrono::high_resolution_clock::now();
    auto durationSTL = chrono::duration_cast<chrono::microseconds>(endSTL - startSTL).count();
    
    cout << "Lookup Time (avl_map): " << durationAVL << " microseconds." << endl;
    cout << "Lookup Time (std::map): " << durationSTL << " microseconds." << endl;
    
    return 0;
}
