#ifndef CITY_H
#define CITY_H

#include <string>

/*************************************************************
 * Class: USCity
 * Date Created: 2025-02-27
 * Description: Represents a US city with attributes such as
 * city name, state, county, zip type, and timezone.
 *************************************************************/
class USCity {
public:
    std::string city;
    std::string state;
    std::string county;
    std::string zipType;
    std::string timezone;

    /*************************************************************
     * Constructor: USCity  
     * Date Created: 2025-02-27
     * Description: Default constructor initializes an empty city object.
     *************************************************************/
    USCity() {}

    /*************************************************************
     * Constructor: USCity 
     * Date Created: 2025-03-02
     * Description: Constructs a USCity object with given parameters
     * including city name, state, county, zip type, and timezone.
     *************************************************************/
    USCity(const std::string &cityParam, const std::string &stateParam,
           const std::string &countyParam, const std::string &zipTypeParam,
           const std::string &timezoneParam)
        : city(cityParam), state(stateParam), county(countyParam),
          zipType(zipTypeParam), timezone(timezoneParam) {}
};

#endif
