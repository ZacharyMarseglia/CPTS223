#ifndef AVL_H
#define AVL_H

#include <iostream>
#include <algorithm>

/*************************************************************
 * Class: avl_map
 * Date Created: 2025-02-27
 * Description: Implements an AVL tree-based map that stores
 * key-value pairs. Supports insertion, deletion, lookup,
 * and in-order traversal while maintaining balance.
 *************************************************************/
template <typename Key, typename Value>
class avl_map {
private:
    /*************************************************************
     * Struct: Node
     * Description: Represents a node in the AVL tree, storing a
     * key-value pair, left/right child pointers, and height.
     *************************************************************/
    struct Node {
        Key key;
        Value value;
        Node* left;
        Node* right;
        int height;

        Node(const Key& k, const Value& v)
            : key(k), value(v), left(nullptr), right(nullptr), height(1) {}
    };

    Node* root;

    // Helper function to get the height of a node
    int height(Node* node) const {
        return node ? node->height : 0;
    }

    // Compute balance factor of a node
    int getBalance(Node* node) const {
        return node ? height(node->left) - height(node->right) : 0;
    }

    // Right Rotation (LL Case)
    Node* rightRotate(Node* y) {
        Node* x = y->left;
        Node* T2 = x->right;
        x->right = y;
        y->left = T2;
        y->height = std::max(height(y->left), height(y->right)) + 1;
        x->height = std::max(height(x->left), height(x->right)) + 1;
        return x;
    }

    // Left Rotation (RR Case)
    Node* leftRotate(Node* x) {
        Node* y = x->right;
        Node* T2 = y->left;
        y->left = x;
        x->right = T2;
        x->height = std::max(height(x->left), height(x->right)) + 1;
        y->height = std::max(height(y->left), height(y->right)) + 1;
        return y;
    }

    // Recursive insert function
    Node* insert(Node* node, const Key& key, const Value& value) {
        if (!node) return new Node(key, value);

        if (key < node->key)
            node->left = insert(node->left, key, value);
        else if (key > node->key)
            node->right = insert(node->right, key, value);
        else {
            node->value = value;  // Update existing key
            return node;
        }

        // Update height
        node->height = 1 + std::max(height(node->left), height(node->right));

        // Rebalance the node
        int balance = getBalance(node);

        // Left Heavy (LL)
        if (balance > 1 && key < node->left->key)
            return rightRotate(node);

        // Right Heavy (RR)
        if (balance < -1 && key > node->right->key)
            return leftRotate(node);

        // Left-Right Case (LR)
        if (balance > 1 && key > node->left->key) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }

        // Right-Left Case (RL)
        if (balance < -1 && key < node->right->key) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }

        return node;
    }

    // Recursive deletion function
    Node* erase(Node* node, const Key& key) {
        if (!node) return nullptr;

        if (key < node->key)
            node->left = erase(node->left, key);
        else if (key > node->key)
            node->right = erase(node->right, key);
        else {
            if (!node->left || !node->right) {
                Node* temp = node->left ? node->left : node->right;
                if (!temp) {
                    temp = node;
                    node = nullptr;
                } else {
                    *node = *temp;
                }
                delete temp;
            } else {
                Node* temp = minValueNode(node->right);
                node->key = temp->key;
                node->value = temp->value;
                node->right = erase(node->right, temp->key);
            }
        }

        if (!node) return node;

        node->height = 1 + std::max(height(node->left), height(node->right));
        int balance = getBalance(node);

        if (balance > 1 && getBalance(node->left) >= 0)
            return rightRotate(node);

        if (balance > 1 && getBalance(node->left) < 0) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }

        if (balance < -1 && getBalance(node->right) <= 0)
            return leftRotate(node);

        if (balance < -1 && getBalance(node->right) > 0) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }

        return node;
    }

    // Find the node with the smallest key (used for deletion)
    Node* minValueNode(Node* node) {
        Node* current = node;
        while (current->left)
            current = current->left;
        return current;
    }

    // Recursive function to find a key in the tree
    Node* find(Node* node, const Key& key) const {
        if (!node) return nullptr;
        if (key < node->key) return find(node->left, key);
        if (key > node->key) return find(node->right, key);
        return node;
    }

    // Recursive function to delete all nodes
    void deleteTree(Node* node) {
        if (!node) return;
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }

public:
    /*************************************************************
     * Constructor: avl_map
     * Description: Initializes an empty AVL map.
     *************************************************************/
    avl_map() : root(nullptr) {}

    /*************************************************************
     * Destructor: ~avl_map
     * Description: Destroys the AVL tree and frees all memory.
     *************************************************************/
    ~avl_map() { deleteTree(root); }

    /*************************************************************
     * Function: insert
     * Description: Inserts a key-value pair into the AVL tree.
     *************************************************************/
    void insert(const Key& key, const Value& value) {
        root = insert(root, key, value);
    }

    /*************************************************************
     * Function: erase
     * Description: Removes the node with the specified key.
     *************************************************************/
    void erase(const Key& key) {
        root = erase(root, key);
    }

    /*************************************************************
     * Function: find
     * Description: Searches for a key. If found, returns true
     * and assigns the corresponding value. Otherwise, returns false.
     *************************************************************/
    bool find(const Key& key, Value& value) const {
        Node* node = find(root, key);
        if (node) {
            value = node->value;
            return true;
        }
        return false;
    }
};

#endif
