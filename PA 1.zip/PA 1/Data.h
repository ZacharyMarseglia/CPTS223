#ifndef DATA_H
#define DATA_H

#include <iostream>
#include <string>

class Data {
private:
    std::string command;
    std::string description;
    int points;

public:
    Data(const std::string& cmd = "", const std::string& desc = "", int pts = 0)
        : command(cmd), description(desc), points(pts) {}

    std::string getCommand() const { return command; }
    std::string getDescription() const { return description; }
    int getPoints() const { return points; }

    void setCommand(const std::string& cmd) { command = cmd; }
    void setDescription(const std::string& desc) { description = desc; }
    void setPoints(int pts) { points = pts; }

    bool operator==(const Data& other) const {
        return command == other.command && description == other.description && points == other.points;
    }

    friend std::ostream& operator<<(std::ostream& os, const Data& data) {
        os << "[Command: " << data.command << ", Description: " << data.description << ", Points: " << data.points << "]";
        return os;
    }
};

#endif
