#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>
#include <stdexcept>

template <typename T>
class Node {
public:
    T data;
    Node<T>* next;

    Node(const T& data) : data(data), next(nullptr) {}
};

template <typename T>
class LinkedList {
private:
    Node<T>* head;
    int size;

public:
    LinkedList() : head(nullptr), size(0) {}

    ~LinkedList() {
        Node<T>* current = head;
        while (current) {
            Node<T>* next = current->next;
            delete current;
            current = next;
        }
    }

    void insertAtFront(const T& data) {
        Node<T>* newNode = new Node<T>(data);
        newNode->next = head;
        head = newNode;
        size++;
    }

    bool removeNode(const T& data) {
        if (!head) {
            std::cout << "List is empty, cannot remove." << std::endl;
            return false;
        }

        if (head->data == data) {
            Node<T>* temp = head;
            head = head->next;
            delete temp;
            size--;
            std::cout << "Removed node: " << data << std::endl;
            return true;
        }

        Node<T>* current = head;
        while (current->next && !(current->next->data == data)) {
            current = current->next;
        }

        if (current->next) {
            Node<T>* temp = current->next;
            current->next = current->next->next;
            delete temp;
            size--;
            std::cout << "Removed node: " << data << std::endl;
            return true;
        }

        std::cout << "Node not found: " << data << std::endl;
        return false;
    }

    void displayAll() const {
        if (!head) {
            std::cout << "List is empty." << std::endl;
            return;
        }

        Node<T>* current = head;
        while (current) {
            std::cout << current->data << std::endl;
            current = current->next;
        }
    }

    int getSize() const {
        return size;
    }

    Node<T>* getHead() const {
        return head;
    }
};

#endif
