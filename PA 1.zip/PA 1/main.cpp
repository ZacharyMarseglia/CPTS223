/*************************************************************
 * Class: CPTS223                                            *
 * Date Created: 2025-01-29                                  *
 * Description:PA 1                                          *
 *************************************************************/
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <limits>
#include "LinkedList.h"
#include "Data.h"

using namespace std;

const string COMMANDS_FILE = "commands.csv";
const string PROFILES_FILE = "profiles.csv";

class Game {
private:
    LinkedList<Data> commandsList;
    vector<pair<string, int>> profiles;

    void loadCommands();
    void saveCommands();
    void loadProfiles();
    void saveProfiles();
    void playGame();
    void addCommand();
    void removeCommand();
    void displayRules();

public:
    Game();
    ~Game();
    void run();
};

/*************************************************************
 * Function: loadCommands                                    *
 * Date Created: 2025-01-29                                  *
 * Description: Loads commands from file.                   *
 *************************************************************/
void Game::loadCommands() {
    ifstream file(COMMANDS_FILE);
    if (!file) return;

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string cmd, desc;
        int pts;
        if (!getline(ss, cmd, ',') || !getline(ss, desc, ',') || !(ss >> pts)) continue;
        commandsList.insertAtFront(Data(cmd, desc, pts));
    }
    file.close();
}

/*************************************************************
 * Function: saveCommands                                    *
 * Date Created: 2025-01-29                                  *
 * Description: Saves commands to file.                     *
 *************************************************************/
void Game::saveCommands() {
    ofstream file(COMMANDS_FILE);
    Node<Data>* current = commandsList.getHead();
    while (current) {
        file << current->data.getCommand() << ","
             << current->data.getDescription() << ","
             << current->data.getPoints() << endl;
        current = current->next;
    }
    file.close();
}

/*************************************************************
 * Function: loadProfiles                                    *
 * Date Created: 2025-02-01                                  *
 * Description: Loads player scores from file.              *
 *************************************************************/
void Game::loadProfiles() {
    ifstream file(PROFILES_FILE);
    if (!file) return;

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string name;
        int score;
        if (!getline(ss, name, ',') || !(ss >> score)) continue;
        profiles.push_back({name, score});
    }
    file.close();
}

/*************************************************************
 * Function: saveProfiles                                    *
 * Date Created: 2025-02-02                                  *
 * Description: Saves player scores to file.                *
 *************************************************************/
void Game::saveProfiles() {
    ofstream file(PROFILES_FILE);
    for (const auto& profile : profiles) {
        file << profile.first << "," << profile.second << endl;
    }
    file.close();
}

/*************************************************************
 * Function: playGame                                        *
 * Date Created: 2025-02-01                                  *
 * Description: Starts a game session.                      *
 *************************************************************/
void Game::playGame() {
    if (commandsList.getSize() == 0) {
        cout << "No commands available!" << endl;
        return;
    }

    string playerName;
    int numQuestions;
    cout << "Enter name: ";
    cin >> playerName;

    cout << "Enter number of questions: ";
    while (!(cin >> numQuestions) || numQuestions <= 0) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid! Enter a positive number: ";
    }

    int score = 0;
    srand(time(0));

    for (int i = 0; i < numQuestions; i++) {
        int randomIndex = rand() % commandsList.getSize();
        Node<Data>* current = commandsList.getHead();
        for (int j = 0; current && j < randomIndex; j++) {
            current = current->next;
        }

        if (!current) continue;

        cout << "Command: " << current->data.getCommand() << endl;
        cout << "Description: " << current->data.getDescription() << endl;
        cout << "Enter correct command: ";

        string answer;
        cin >> answer;

        if (answer == current->data.getCommand()) {
            score += current->data.getPoints();
            cout << "Correct! Score: " << score << endl;
        } else {
            score -= current->data.getPoints();
            cout << "Incorrect! Score: " << score << endl;
        }
    }

    cout << "Final Score: " << score << endl;
    profiles.push_back({playerName, score});
    saveProfiles();
}

/*************************************************************
 * Function: addCommand                                      *
 * Date Created: 2025-02-01                                  *
 * Description: Adds a new command.                         *
 *************************************************************/
void Game::addCommand() {
    string cmd, desc;
    int pts;

    cout << "Enter command: ";
    cin.ignore();
    getline(cin, cmd);

    cout << "Enter description: ";
    getline(cin, desc);

    cout << "Enter points: ";
    while (!(cin >> pts)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid! Enter an integer: ";
    }

    commandsList.insertAtFront(Data(cmd, desc, pts));
    saveCommands();
    cout << "Command added!\n";
}

/*************************************************************
 * Function: removeCommand                                   *
 * Date Created: 2025-02-01                                  *
 * Description: Removes a command.                          *
 *************************************************************/
void Game::removeCommand() {
    string cmd;
    cout << "Enter command to remove: ";
    cin.ignore();
    getline(cin, cmd);

    if (commandsList.removeNode(Data(cmd, "", 0))) {
        saveCommands();
        cout << "Command removed!\n";
    } else {
        cout << "Command not found.\n";
    }
}

/*************************************************************
 * Function: displayRules                                    *
 * Date Created: 2025-02-01                                  *
 * Description: Shows game rules.                           *
 *************************************************************/
void Game::displayRules() {
    cout << "Game Rules:\n";
    cout << "1. Match commands with descriptions.\n";
    cout << "2. Earn or lose points.\n";
    cout << "3. Save progress.\n";
}

/*************************************************************
 * Function: Game()                                          *
 * Date Created: 2025-01-29                                  *
 * Description: Loads game data.                             *
 *************************************************************/
Game::Game() {
    loadCommands();
    loadProfiles();
}

/*************************************************************
 * Function: ~Game()                                         *
 * Date Created: 2025-02-02                                  *
 * Description: Saves game data before exiting.             *
 *************************************************************/
Game::~Game() {
    saveCommands();
    saveProfiles();
}

/*************************************************************
 * Function: run                                             *
 * Date Created: 2025-02-02                                  *
 * Description: Runs the main menu.                          *
 *************************************************************/
void Game::run() {
    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Game Rules\n";
        cout << "2. Play Game\n";
        cout << "3. Load Previous Scores\n";
        cout << "4. Add Command\n";
        cout << "5. Remove Command\n";
        cout << "6. Display Commands\n";
        cout << "7. Exit\n";
        cout << "Enter choice: ";

        int choice;
        while (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid! Enter a number: ";
        }

        switch (choice) {
            case 1:
                displayRules();
                break;
            case 2:
                playGame();
                break;
            case 3:
                cout << "Previous scores:\n";
                for (const auto& profile : profiles) {
                    cout << profile.first << ": " << profile.second << " points\n";
                }
                break;
            case 4:
                addCommand();
                break;
            case 5:
                removeCommand();
                break;
            case 6:
                commandsList.displayAll();
                break;
            case 7:
                return;
            default:
                cout << "Invalid choice!\n";
        }
    }
}

int main() {
    Game game;
    game.run();
    return 0;
}

