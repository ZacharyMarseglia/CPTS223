#include "HashTable.hpp"

HashTable::HashTable() {
    for (int i = 0; i < TABLE_SIZE; ++i)
        table[i] = nullptr;
}

HashTable::~HashTable() {
    for (int i = 0; i < TABLE_SIZE; ++i) {
        Product* curr = table[i];
        while (curr) {
            Product* tmp = curr;
            curr = curr->next;
            delete tmp;
        }
    }
}

int HashTable::hash(const std::string& key) const {
    unsigned long h = 0;
    for (unsigned char c : key) h = h * 31 + c;
    return h % TABLE_SIZE;
}

void HashTable::insert(Product* product) {
    int idx = hash(product->uniq_id);
    product->next = table[idx];
    table[idx] = product;
}

Product* HashTable::find(const std::string& id) const {
    int idx = hash(id);
    Product* curr = table[idx];
    while (curr) {
        if (curr->uniq_id == id) return curr;
        curr = curr->next;
    }
    return nullptr;
}
