#ifndef SORT_HPP
#define SORT_HPP

#include <vector>

/*************************************************************
 * Function: insertionSort
 * Date Created: 2025-04-20
 * Description: Performs an in-place insertion sort on the
 *              vector 'a' using the provided comparison
 *              functor 'comp'.
 *************************************************************/
template<typename T, typename Compare>
void insertionSort(std::vector<T>& a, Compare comp) {
    for (size_t i = 1; i < a.size(); ++i) {
        T key = a[i];
        int j = int(i) - 1;
        while (j >= 0 && comp(key, a[j])) {
            a[j+1] = a[j];
            --j;
        }
        a[j+1] = key;
    }
}

/*************************************************************
 * Function: merge
 * Date Created: 2025-04-20
 * Description: Merges two sorted subranges [lo..mid] and
 *              [mid+1..hi] of vector 'a' into a single
 *              sorted sequence according to 'comp'.
 *************************************************************/
template<typename T, typename Compare>
void merge(std::vector<T>& a, size_t lo, size_t mid, size_t hi, Compare comp) {
    std::vector<T> temp;
    temp.reserve(hi - lo + 1);
    size_t i = lo, j = mid + 1;
    while (i <= mid && j <= hi) {
        if (comp(a[i], a[j])) temp.push_back(a[i++]);
        else                   temp.push_back(a[j++]);
    }
    while (i <= mid) temp.push_back(a[i++]);
    while (j <= hi)  temp.push_back(a[j++]);
    for (size_t k = 0; k < temp.size(); ++k)
        a[lo + k] = temp[k];
}

/*************************************************************
 * Function: mergeSort (recursive)
 * Date Created: 2025-04-20
 * Description: Recursively sorts the subrange [lo..hi]
 *              of vector 'a' using merge sort algorithm
 *              and comparator 'comp'.
 *************************************************************/
template<typename T, typename Compare>
void mergeSort(std::vector<T>& a, Compare comp, size_t lo, size_t hi) {
    if (lo >= hi) return;
    size_t mid = (lo + hi) / 2;
    mergeSort(a, comp, lo, mid);
    mergeSort(a, comp, mid+1, hi);
    merge(a, lo, mid, hi, comp);
}

/*************************************************************
 * Function: mergeSort
 * Date Created: 2025-04-20
 * Description: Entry point for merge sort; sorts entire
 *              vector 'a' in-place using comparator 'comp'.
 *************************************************************/
template<typename T, typename Compare>
void mergeSort(std::vector<T>& a, Compare comp) {
    if (!a.empty()) mergeSort(a, comp, 0, a.size() - 1);
}

#endif
