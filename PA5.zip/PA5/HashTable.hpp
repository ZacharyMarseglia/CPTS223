#ifndef HASHTABLE_HPP
#define HASHTABLE_HPP
#include "Product.hpp"
#include <string>
const int TABLE_SIZE = 10007;

/*************************************************************
 * Class: HashTable
 * Date Created: 2025-03-27
 * Description: 
 *   A simple hash table mapping unique product IDs to
 *   Product pointers for O(1) average lookup.
 *************************************************************/
class HashTable {
public:
    /*********************************************************
     * Function: HashTable::HashTable
     * Date Created: 2025-03-27
     * Description: 
     *   Allocates and zero‑initializes all buckets.
     *********************************************************/
    HashTable();

    /*********************************************************
     * Function: HashTable::~HashTable
     * Date Created: 2025-03-27
     * Description: 
     *   Frees all Products stored in the table to avoid leaks.
     *********************************************************/
    ~HashTable();

    /*********************************************************
     * Function: HashTable::insert
     * Date Created: 2025-03-29
     * Description: 
     *   Computes bucket index via hash(uniq_id) and inserts
     *   the new Product at the head of that bucket’s chain.
     * Parameters:
     *   product – pointer to a dynamically‑allocated Product
     *********************************************************/
    void insert(Product* product);

    /*********************************************************
     * Function: HashTable::find
     * Date Created: 2025-03-29
     * Description: 
     *   Looks up a Product by its unique ID string.
     * Parameters:
     *   id – the uniq_id to search for
     * Returns:
     *   pointer to the matching Product, or nullptr if none
     *********************************************************/
    Product* find(const std::string& id) const;

private:
    /*********************************************************
     * Function: HashTable::hash
     * Date Created: 2025-03-27
     * Description: 
     *   Simple rolling‑hash: multiplies accumulator by 31,
     *   adds each character, then mods by TABLE_SIZE.
     * Parameters:
     *   key – string to hash
     * Returns:
     *   bucket index in [0..TABLE_SIZE)
     *********************************************************/
    int hash(const std::string& key) const;

    Product* table[TABLE_SIZE];
};

#endif 
