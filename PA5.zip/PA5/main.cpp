#include "HashTable.hpp"
#include "CategoryMap.hpp"
#include "Sort.hpp"
#include <functional>   
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <limits>

using namespace std;

HashTable   inventoryTable;
CategoryMap categoryMap;

/*************************************************************
 * Function: printHelp
 * Description: Displays supported commands and usage.
 *************************************************************/
void printHelp() {
    cout << "Supported commands:\n";
    cout << "  find <inventoryid>\n";
    cout << "  listInventory <category> [merge] [desc]\n";
    cout << "    - default: insertion sort ascending\n";
    cout << "    - desc: insertion sort descending\n";
    cout << "    - merge: merge sort ascending\n";
    cout << "    - merge desc: merge sort descending\n";
}

/*************************************************************
 * Function: validCommand
 * Description: Checks if input is a recognized command.
 *************************************************************/
bool validCommand(const string& line) {
    return line == ":help"
        || line.rfind("find", 0) == 0
        || line.rfind("listInventory", 0) == 0;
}

/*************************************************************
 * Function: evalCommand
 * Description: Parses and executes 'find' or 'listInventory'.
 *************************************************************/
void evalCommand(const string& line) {
    if (line == ":help") {
        printHelp();
        return;
    }

    istringstream iss(line);
    string cmd;
    iss >> cmd;

    if (cmd == "find") {
        string id;
        iss >> id;
        Product* p = inventoryTable.find(id);
        if (p) {
            cout << "Product Found:\n"
                 << "ID: "           << p->uniq_id       << "\n"
                 << "Name: "         << p->product_name << "\n"
                 << "Category: "     << p->category     << "\n"
                 << "Selling Price: "<< p->selling_price << "\n";
        } else {
            cout << "Inventory/Product not found\n";
        }
        return;
    }

    if (cmd == "listInventory") {
        string category;
        iss >> ws;
        if (iss.peek() == '"') {
            iss.get();  
            getline(iss, category, '"');
        } else {
            iss >> category;
        }
        bool useMerge = false, useDesc = false;
        string opt;
        while (iss >> opt) {
            if (opt == "merge")      useMerge = true;
            else if (opt == "desc")  useDesc  = true;
        }

        // lookup products
        string key = category;
        transform(key.begin(), key.end(), key.begin(), ::tolower);
        auto results = categoryMap.getProducts(key);
        if (results.empty()) {
            cout << "Invalid Category\n";
            return;
        }

        // comparators
        auto asc  = [](Product* a, Product* b){ return a->selling_price <  b->selling_price; };
        auto desc = [](Product* a, Product* b){ return a->selling_price >  b->selling_price; };
        auto comp = useDesc ? desc : asc;

        // sort
        if (useMerge) mergeSort(results, comp);
        else           insertionSort(results, comp);

        // print
        for (auto p : results) {
            cout << p->uniq_id << ", " << p->product_name << "\n";
        }
        return;
    }

    cout << "Command not supported. Enter :help for help\n";
}

/*************************************************************
 * Function: bootStrap
 * Description: Loads CSV, builds HashTable and CategoryMap.
 *************************************************************/
void bootStrap() {
    cout << "\n Welcome to Amazon Inventory Query System\n";
    cout << " enter :quit to exit, :help for help.\n\n> ";

    ifstream file("marketing_sample_for_amazon_com-ecommerce__20200101_20200131__10k_data.csv");
    if (!file.is_open()) {
        cout << "Failed to open CSV file\n";
        return;
    }

    string line;
    getline(file, line); 
    while (getline(file, line)) {
        vector<string> fields;
        string field;
        bool inQ = false;
        for (char c : line) {
            if (c == '"') inQ = !inQ;
            if (c == ',' && !inQ) {
                fields.push_back(field);
                field.clear();
            } else {
                field += c;
            }
        }
        fields.push_back(field);
        if (fields.size() < 8) continue;

        auto trim = [&](string& s) {
            s.erase(0, s.find_first_not_of(" \t\n\r"));
            s.erase(s.find_last_not_of(" \t\n\r") + 1);
        };

        trim(fields[0]); trim(fields[1]); trim(fields[4]); trim(fields[7]);

        auto p = new Product();
        p->uniq_id       = fields[0];
        p->product_name  = fields[1];
        p->category      = fields[4].empty() ? "NA" : fields[4];
        string num;
        for (char c : fields[7]) if (isdigit(c)||c=='.'||c=='-') num += c;
        p->selling_price = num.empty() ? 0.0 : stod(num);
        p->next          = nullptr;
        inventoryTable.insert(p);

        istringstream ss(p->category);
        string sub;
        while (getline(ss, sub, '|')) {
            trim(sub);
            categoryMap.insert(sub, p);
        }
    }
}

int main() {
    bootStrap();
    string line;
    while (getline(cin, line) && line != ":quit") {
        if (validCommand(line)) evalCommand(line);
        else                    cout << "Command not supported. Enter :help for help\n";
        cout << "> " << flush;
    }
    return 0;
}
