#include "CategoryMap.hpp"
#include <algorithm>
#include <cctype>

CategoryMap::CategoryMap() {}
CategoryMap::~CategoryMap() {}

void CategoryMap::insert(const std::string& category, Product* product) {
    std::string key = category;
    std::transform(key.begin(), key.end(), key.begin(), ::tolower);
    map_[key].push_back(product);
}

std::vector<Product*> CategoryMap::getProducts(const std::string& query) const {
    std::string q = query;
    std::transform(q.begin(), q.end(), q.begin(), ::tolower);

    std::vector<Product*> result;
    for (auto& kv : map_) {
        if (kv.first.find(q) != std::string::npos) {
            result.insert(result.end(), kv.second.begin(), kv.second.end());
        }
    }
    return result;
}
