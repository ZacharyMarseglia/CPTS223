#ifndef CATEGORYMAP_HPP
#define CATEGORYMAP_HPP
#include <string>
#include <vector>
#include <unordered_map>
#include "Product.hpp"


/*************************************************************
 * Class: CategoryMap
 * Date Created: 2025-04-20
 * Description: 
 *   Maintains a mapping from lower‑cased category strings
 *   to lists of Product pointers for fast lookup by substring.
 *************************************************************/
class CategoryMap {
public:
    /*********************************************************
     * Function: CategoryMap::CategoryMap
     * Date Created: 2025-04-20
     * Description: 
     *   Constructor initializes the internal map to empty.
     *********************************************************/
    CategoryMap();
    /*********************************************************
     * Function: CategoryMap::~CategoryMap
     * Date Created: 2025-04-20
     * Description: 
     *   Destructor clears the map data (does not delete Products).
     *********************************************************/
    ~CategoryMap();

    /*********************************************************
     * Function: CategoryMap::insert
     * Date Created: 2025-04-20
     * Description: 
     *   Inserts a Product pointer under the specified category key.
     *   The key is stored lower‑cased.
     * Parameters:
     *   category – original category string
     *   product  – pointer to Product to add
     *********************************************************/
    void insert(const std::string& category, Product* product);

    
    /*********************************************************
     * Function: CategoryMap::getProducts
     * Date Created: 2025-04-20
     * Description: 
     *   Returns all Products whose stored category keys 
     *   contain the lower‑cased query as a substring.
     * Parameters:
     *   query – lower‑cased substring to match
     * Returns:
     *   vector of matching Product pointers (empty if none)
     *********************************************************/
    std::vector<Product*> getProducts(const std::string& query) const;

private:
    std::unordered_map<std::string, std::vector<Product*>> map_;
};

#endif 
