#ifndef PRODUCT_HPP
#define PRODUCT_HPP

#include <string>

/*************************************************************
 * Struct: Product
 * Date Created: 2025-03-27
 * Description: Holds product data, used by HashTable and CategoryMap.
 *************************************************************/
struct Product {
    std::string uniq_id;
    std::string product_name;
    std::string category;
    double      selling_price;
    Product*    next; 
};

#endif 
