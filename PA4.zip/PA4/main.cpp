#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

const int TABLE_SIZE = 10007;

/*************************************************************
 * Struct: Product
 * Date Created: 2025-03-27
 * Description: Holds product data, used by HashTable 
 *              and CategoryList.
 *************************************************************/
struct Product {
    string uniq_id;        
    string product_name;   
    string category;       
    Product* next;         
};

/*************************************************************
 * Class: HashTable
 * Date Created: 2025-03-27
 * Description: Implements a hash table to store (uniq_id -> Product)
 *              for quick lookups by ID. 
 *************************************************************/
class HashTable {
public:
    /*************************************************************
     * Function: HashTable::HashTable
     * Date Created: 2025-03-27
     * Description: Constructor initializes all buckets to nullptr.
     *************************************************************/
    HashTable();

    /*************************************************************
     * Function: HashTable::~HashTable
     * Date Created: 2025-03-27
     * Description: Destructor frees all Products in each bucket.
     *************************************************************/
    ~HashTable();

    /*************************************************************
     * Function: HashTable::insert
     * Date Created: 2025-03-29
     * Description: Inserts a new Product into the table by its uniq_id.
     *************************************************************/
    void insert(Product* product);

    /*************************************************************
     * Function: HashTable::find
     * Date Created: 2025-03-29
     * Description: Looks up a Product by uniq_id. Returns pointer
     *              if found, else nullptr.
     *************************************************************/
    Product* find(const string& id);

private:
    Product* table[TABLE_SIZE];

    /*************************************************************
     * Function: HashTable::hash
     * Date Created: 2025-03-27
     * Description: Simple string-hash function. Accumulates a value
     *              for each char in the key, modded by TABLE_SIZE.
     *************************************************************/
    int hash(const string& key);
};

/*************************************************************
 * Function: HashTable::HashTable (Constructor)
 * Date Created: 2025-03-27
 * Description: Zero-initializes each array bucket to nullptr.
 *************************************************************/
HashTable::HashTable() {
    for (int i = 0; i < TABLE_SIZE; ++i) {
        table[i] = nullptr;
    }
}

/*************************************************************
 * Function: HashTable::~HashTable (Destructor)
 * Date Created: 2025-03-27
 * Description: Iterates over all buckets, deleting the linked
 *              collision chains of Products.
 *************************************************************/
HashTable::~HashTable() {
    for (int i = 0; i < TABLE_SIZE; ++i) {
        Product* curr = table[i];
        while (curr) {
            Product* temp = curr;
            curr = curr->next;
            delete temp;
        }
    }
}

/*************************************************************
 * Function: HashTable::hash
 * Date Created: 2025-03-27
 * Description: Multiplies 'h' by 31 for each char in key, plus
 *              the char's ASCII value, then mod by TABLE_SIZE.
 *************************************************************/
int HashTable::hash(const string& key) {
    unsigned long h = 0;
    for (char c : key) {
        h = h * 31 + static_cast<unsigned char>(c);
    }
    return h % TABLE_SIZE;
}

/*************************************************************
 * Function: HashTable::insert
 * Date Created: 2025-03-29
 * Description: Finds the correct bucket via hash(uniq_id). 
 *              Inserts product at head of collision list.
 *************************************************************/
void HashTable::insert(Product* product) {
    int index = hash(product->uniq_id);
    product->next = table[index];
    table[index] = product;
}

/*************************************************************
 * Function: HashTable::find
 * Date Created: 2025-03-29
 * Description: Hashes 'id' to find the correct bucket, then
 *              traverses the chain until matching uniq_id
 *              or end of list.
 *************************************************************/
Product* HashTable::find(const string& id) {
    int index = hash(id);
    Product* curr = table[index];
    while (curr) {
        if (curr->uniq_id == id) {
            return curr;
        }
        curr = curr->next;
    }
    return nullptr;
}

/*************************************************************
 * Class: CategoryList
 * Date Created: 2025-03-30
 * Description: Stores (category, product) pairs in a linked list
 *              for partial substring matching. 
 *************************************************************/
class CategoryList {
public:
    /*************************************************************
     * Function: CategoryList::CategoryList
     * Date Created: 2025-03-30
     * Description: Initializes list head to nullptr.
     *************************************************************/
    CategoryList();

    /*************************************************************
     * Function: CategoryList::~CategoryList
     * Date Created: 2025-03-30
     * Description: Frees all dynamically allocated Nodes.
     *************************************************************/
    ~CategoryList();

    /*************************************************************
     * Function: CategoryList::insert
     * Date Created: 2025-03-30
     * Description: Inserts a new node with category + product
     *              at the head of the linked list.
     *************************************************************/
    void insert(const string& category, Product* product);

    /*************************************************************
     * Function: CategoryList::list
     * Date Created: 2025-03-30
     * Description: Prints all products whose category (case-insensitive)
     *              contains the user input string. If none found, prints
     *              'Invalid Category'.
     *************************************************************/
    void list(const string& category);

private:
    struct Node {
        string category;
        Product* product;
        Node* next;
    };
    Node* head;
};

/*************************************************************
 * Function: CategoryList::CategoryList (Constructor)
 * Date Created: 2025-03-30
 * Description: Sets head to nullptr since the list is initially empty.
 *************************************************************/
CategoryList::CategoryList() : head(nullptr) {}

/*************************************************************
 * Function: CategoryList::~CategoryList (Destructor)
 * Date Created: 2025-03-30
 * Description: Traverses the list, deletes each Node.
 *************************************************************/
CategoryList::~CategoryList() {
    while (head) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}

/*************************************************************
 * Function: CategoryList::insert
 * Date Created: 2025-03-30
 * Description: Creates a new Node with the provided category
 *              and product, inserting it at the front of list.
 *************************************************************/
void CategoryList::insert(const string& category, Product* product) {
    Node* newNode = new Node{category, product, head};
    head = newNode;
}

/*************************************************************
 * Function: CategoryList::list
 * Date Created: 2025-03-30
 * Description: Does a partial substring match on each stored
 *              category. Prints matching product info or
 *              'Invalid Category' if none found.
 *************************************************************/
void CategoryList::list(const string& category) {
    bool found = false;
    string inputLower = category;
    for (char& c : inputLower) {
        c = tolower(c);
    }
    Node* curr = head;
    while (curr) {
        string catLower = curr->category;
        for (char& c : catLower) {
            c = tolower(c);
        }
        if (catLower.find(inputLower) != string::npos) {
            cout << curr->product->uniq_id << ", "
                 << curr->product->product_name << "\n";
            found = true;
        }
        curr = curr->next;
    }
    if (!found) {
        cout << "Invalid Category\n";
    }
}

HashTable inventoryTable;
CategoryList categoryList;

/*************************************************************
 * Function: printHelp
 * Date Created: 2025-03-27
 * Description: Displays the supported commands and usage info.
 *************************************************************/
void printHelp() {
    cout << "Supported list of commands: \n";
    cout << " 1. find <inventoryid> - Finds if the inventory exists. If exists, prints details. If not, prints 'Inventory not found'.\n";
    cout << " 2. listInventory <category_string> - Lists just the id and name of all inventory belonging to the specified category. If the category doesn't exist, prints 'Invalid Category'.\n\n";
}

/*************************************************************
 * Function: validCommand
 * Date Created: 2025-03-27
 * Description: Checks if the user input starts with a known command.
 *************************************************************/
bool validCommand(string line) {
    return (line == ":help") ||
           (line.rfind("find", 0) == 0) ||
           (line.rfind("listInventory", 0) == 0);
}

/*************************************************************
 * Function: evalCommand
 * Date Created: 2025-03-29
 * Description: Parses the user input line, identifies command,
 *              and performs the requested action (find or list).
 *************************************************************/
void evalCommand(string line) {
    if (line == ":help") {
        printHelp();
    } else if (line.rfind("find", 0) == 0) {
        string id = line.substr(5);
        id.erase(0, id.find_first_not_of(" \t\n\r"));
        id.erase(id.find_last_not_of(" \t\n\r") + 1);
        Product* product = inventoryTable.find(id);
        if (product) {
            cout << "Product Found:\n";
            cout << "ID: " << product->uniq_id << "\n";
            cout << "Name: " << product->product_name << "\n";
            cout << "Category: " << product->category << "\n";
        } else {
            cout << "Inventory/Product not found\n";
        }
    } else if (line.rfind("listInventory", 0) == 0) {
        string category = line.substr(14);
        category.erase(0, category.find_first_not_of(" \t\n\r"));
        category.erase(category.find_last_not_of(" \t\n\r") + 1);
        if (!category.empty() && category.front() == '"') {
            category.erase(category.begin());
        }
        if (!category.empty() && category.back() == '"') {
            category.pop_back();
        }
        categoryList.list(category);
    }
}

/*************************************************************
 * Function: bootStrap
 * Date Created: 2025-03-30
 * Description: Reads the CSV file, builds the data structures
 *              (hash table and category list). Prints a welcome
 *              message and initial prompt.
 *************************************************************/
void bootStrap() {
    cout << "\n Welcome to Amazon Inventory Query System\n";
    cout << " enter :quit to exit. or :help to list supported commands.\n\n> ";
    ifstream file("marketing_sample_for_amazon_com-ecommerce__20200101_20200131__10k_data.csv");
    if (!file.is_open()) {
        cout << "Failed to open CSV file!\n";
        return;
    }
    string line;
    getline(file, line);
    while (getline(file, line)) {
        stringstream ss(line);
        string id, name, category, temp;
        getline(ss, id, ',');
        getline(ss, name, ',');
        getline(ss, temp, ',');
        getline(ss, temp, ',');
        getline(ss, category, ',');
        for (int i = 5; i <= 27; i++) {
            getline(ss, temp, ',');
        }
        id.erase(0, id.find_first_not_of(" \t\n\r"));
        id.erase(id.find_last_not_of(" \t\n\r") + 1);
        if (category.empty()) {
            category = "NA";
        }
        Product* product = new Product{id, name, category, nullptr};
        inventoryTable.insert(product);
        stringstream cat_stream(category);
        string cat;
        while (getline(cat_stream, cat, '|')) {
            cat.erase(0, cat.find_first_not_of(" \t\n\r"));
            cat.erase(cat.find_last_not_of(" \t\n\r") + 1);
            categoryList.insert(cat, product);
        }
    }
}

/*************************************************************
 * Function: main
 * Date Created: 2025-03-30
 * Description: Entry point. Calls bootStrap() to load data,
 *              then enters a loop reading user commands until
 *              :quit is typed.
 *************************************************************/
int main(int argc, char const *argv[]) {
    bootStrap();
    string line;
    while (getline(cin, line) && line != ":quit") {
        if (validCommand(line)) {
            evalCommand(line);
        } else {
            cout << "Command not supported. Enter :help for list of supported commands\n";
        }
        cout << "> ";
    }
    return 0;
}
