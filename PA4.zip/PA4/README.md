# PA4
This project is a command-line application that reads from an Amazon product CSV file and allows the user to search the inventory though two commands:

find <inventoryid>

listInventory <category_string>


This application reads an Amazon product CSV and stores each product's details. It supports two commands: find <inventoryid> to look up product information by its unique ID, and listInventory <category> to list all products matching a certain category. Categories may contain multiple values separated by a |.

 It uses a custom hash table to quickly find products by their uniq_id and a simple linked list for storing categories. If the category is empty, it defaults to “NA.” The CSV parsing focuses on the first few columns (uniq_id, product name, etc.) and then splits the category column by the | delimiter to handle multiple categories.

 To compile, run 

 g++ -g -Wall -std=c++14 main.cpp -o mainexe 
 and then 
 ./mainexe. 

 In the program, 
 find <uniq_id> 
 prints details if found. 

 listInventory <category> 
 prints IDs and product names that match that category.

 Use :quit to exit and :help for command info.

An output should be 

find 66d49bbed043f5be260fa9f7fbff5957
Product Found:
ID: 66d49bbed043f5be260fa9f7fbff5957
Name: Electronic Snap Circuits Mini Kits Classpack, FM Radio...
Category: Toys & Games | Learning & Education | Science Kits & Toys

or something like 

listInventory "Arts & Crafts"
2c55cae269aebf53838484b0d7dd931a, 3Doodler Create Flexy 3D Printing Filament Refill Bundle...



with the bad csv file having missing data things with out a category are shown as NA