#include "ListMyJosephus.h"
#include <iostream>

ListMyJosephus::ListMyJosephus(int m, int n)
    : M(m), N(n), currentInitialized(false)
{
}

ListMyJosephus::~ListMyJosephus() {
    clear();
}

void ListMyJosephus::clear() {
    destinations.clear();
    currentInitialized = false;
}

int ListMyJosephus::currentSize() const {
    return destinations.size();
}

bool ListMyJosephus::isEmpty() const {
    return destinations.empty();
}

void ListMyJosephus::populateDestinations(const std::vector<Destination>& dests) {
    clear();
    for (const auto &dest : dests) {
        destinations.push_back(dest);
    }
    if (!destinations.empty()) {
        current = destinations.begin();
        currentInitialized = true;
    }
}

void ListMyJosephus::eliminateDestination() {
    if (destinations.empty() || destinations.size() == 1)
        return;
    
    for (int i = 1; i < M; i++) {
        ++current;
        if (current == destinations.end())
            current = destinations.begin();
    }
    
    std::cout << "Eliminating destination: ";
    current->printPosition();
    std::cout << " - ";
    current->printDestinationName();
    std::cout << std::endl;
    
    current = destinations.erase(current);
    if (current == destinations.end() && !destinations.empty())
        current = destinations.begin();
}

void ListMyJosephus::printAllDestinations() const {
    std::cout << "Remaining destinations:" << std::endl;
    for (const auto &dest : destinations) {
        std::cout << dest.getPosition() << ": " << dest.getName() << std::endl;
    }
}

Destination ListMyJosephus::getLastRemaining() const {
    if (!destinations.empty())
        return destinations.front(); 
    return Destination(-1, "None");
}
