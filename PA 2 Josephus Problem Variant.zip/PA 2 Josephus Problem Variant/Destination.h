#ifndef DESTINATION_H
#define DESTINATION_H

#include <string>
#include <iostream>

class Destination {
public:
/*************************************************************
 * Function: Destination (Constructor)                      *
 * Date Created: 2025-02-10                                   *
 * Description: Initializes a Destination object with the   *
 * provided position and name.                              *
 *************************************************************/
Destination(int pos, const std::string &name);

/*************************************************************
 * Function: ~Destination (Destructor)                      *
 * Date Created: 2025-02-10                                   *
 * Description: Cleans up resources used by the Destination   *
 * object.                                                  *
 *************************************************************/
~Destination();

/*************************************************************
 * Function: printPosition                                  *
 * Date Created: 2025-02-10                                   *
 * Description: Outputs the destination's position to the     *
 * console.                                                 *
 *************************************************************/
void printPosition() const;

/*************************************************************
 * Function: printDestinationName                           *
 * Date Created: 2025-02-10                                   *
 * Description: Outputs the destination's name to the console.*
 *************************************************************/
void printDestinationName() const;

/*************************************************************
 * Function: getPosition                                    *
 * Date Created: 2025-02-10                                   *
 * Description: Returns the position of the destination.     *
 *************************************************************/
int getPosition() const;

/*************************************************************
 * Function: getName                                        *
 * Date Created: 2025-02-10                                   *
 * Description: Returns the name of the destination.         *
 *************************************************************/
std::string getName() const;

    
private:
    int position;           
    std::string name;       
};

#endif 
