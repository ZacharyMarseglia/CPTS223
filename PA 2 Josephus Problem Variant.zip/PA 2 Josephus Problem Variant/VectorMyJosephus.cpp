#include "VectorMyJosephus.h"
#include <iostream>

VectorMyJosephus::VectorMyJosephus(int m, int n)
    : M(m), N(n), currentIndex(0){

    }

VectorMyJosephus::~VectorMyJosephus() {
    clear();
}

void VectorMyJosephus::clear() {
    destinations.clear();
    currentIndex = 0;
}

int VectorMyJosephus::currentSize() const {
    return destinations.size();
}

bool VectorMyJosephus::isEmpty() const {
    return destinations.empty();
}

void VectorMyJosephus::populateDestinations(const std::vector<Destination>& dests) {
    clear();
    destinations = dests;
    currentIndex = 0;
}

void VectorMyJosephus::eliminateDestination() {
    if (destinations.empty() || destinations.size() == 1)
        return;
    
    int eliminationIndex = (currentIndex + M - 1) % destinations.size();
    
    std::cout << "Eliminating destination: ";
    std::cout << destinations[eliminationIndex].getPosition() << " - " 
              << destinations[eliminationIndex].getName() << std::endl;
    
    destinations.erase(destinations.begin() + eliminationIndex);
    
    currentIndex = eliminationIndex % destinations.size();
}

void VectorMyJosephus::printAllDestinations() const {
    std::cout << "Remaining destinations:" << std::endl;
    for (const auto &dest : destinations) {
        std::cout << dest.getPosition() << ": " << dest.getName() << std::endl;
    }
}

Destination VectorMyJosephus::getLastRemaining() const {
    if (!destinations.empty())
        return destinations.front();
    return Destination(-1, "None");
}
