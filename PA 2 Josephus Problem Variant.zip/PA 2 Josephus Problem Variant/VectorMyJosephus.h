#ifndef VECTORMYJOSEPHUS_H
#define VECTORMYJOSEPHUS_H

#include <vector>
#include "Destination.h"

class VectorMyJosephus {
public:
    // Constructor: takes elimination interval M and initial size N.
    VectorMyJosephus(int M, int N);
    // Destructor.
    ~VectorMyJosephus();
    // Empties the sequence.
    void clear();
    // Returns remaining destinations.
    int currentSize() const;
    // Checks if the sequence is empty.
    bool isEmpty() const;
    // Eliminates a destination based on the rules.
    void eliminateDestination();
    // Prints remaining destinations sorted by position.
    void printAllDestinations() const;
    // Populates the container with provided destinations.
    void populateDestinations(const std::vector<Destination>& destinations);
    // Returns the last remaining destination.
    Destination getLastRemaining() const;
    
private:
    int M; // Elimination interval.
    int N; // Total initial destinations.
    std::vector<Destination> destinations;
    int currentIndex; // Current index for elimination.
};

#endif // VECTORMYJOSEPHUS_H
