#ifndef LISTMYJOSEPHUS_H
#define LISTMYJOSEPHUS_H

#include <list>
#include <vector>
#include "Destination.h"

class ListMyJosephus {
public:
    /*************************************************************
     * Function: ListMyJosephus (Constructor)
     * Date Created: 2025-02-10
     * Description: Initializes a ListMyJosephus object with the
     * provided elimination interval (M) and total number of 
     * destinations (N).
     *************************************************************/
    ListMyJosephus(int M, int N);

    /*************************************************************
     * Function: ~ListMyJosephus (Destructor)
     * Date Created: 2025-02-10
     * Description: Cleans up resources used by the ListMyJosephus
     * object.
     *************************************************************/
    ~ListMyJosephus();

    /*************************************************************
     * Function: clear
     * Date Created: 2025-02-10
     * Description: Empties the container of all destinations.
     *************************************************************/
    void clear();

    /*************************************************************
     * Function: currentSize
     * Date Created: 2025-02-10
     * Description: Returns the number of remaining destinations.
     *************************************************************/
    int currentSize() const;

    /*************************************************************
     * Function: isEmpty
     * Date Created: 2025-02-10
     * Description: Checks if the container is empty.
     *************************************************************/
    bool isEmpty() const;

    /*************************************************************
     * Function: eliminateDestination
     * Date Created: 2025-02-10
     * Description: Eliminates a destination according to the
     * elimination rules and updates the current iterator.
     *************************************************************/
    void eliminateDestination();

    /*************************************************************
     * Function: printAllDestinations
     * Date Created: 2025-02-10
     * Description: Prints all remaining destinations in order.
     *************************************************************/
    void printAllDestinations() const;

    /*************************************************************
     * Function: populateDestinations
     * Date Created: 2025-02-10
     * Description: Fills the container with a vector of Destination
     * objects.
     *************************************************************/
    void populateDestinations(const std::vector<Destination>& destinations);

    /*************************************************************
     * Function: getLastRemaining
     * Date Created: 2025-02-10
     * Description: Returns the last remaining destination.
     *************************************************************/
    Destination getLastRemaining() const;
    
private:
    int M;  
    int N;  
    std::list<Destination> destinations;
    std::list<Destination>::iterator current;  
    bool currentInitialized;  
};

#endif
