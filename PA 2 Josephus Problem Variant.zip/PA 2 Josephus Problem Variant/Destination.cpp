#include "Destination.h"

Destination::Destination(int pos, const std::string &name)
    : position(pos), name(name)
{
}

Destination::~Destination() {
}

void Destination::printPosition() const {
    std::cout << position;
}

void Destination::printDestinationName() const {
    std::cout << name;
}

int Destination::getPosition() const {
    return position;
}

std::string Destination::getName() const {
    return name;
}
