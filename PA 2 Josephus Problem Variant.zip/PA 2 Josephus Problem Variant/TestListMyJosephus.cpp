#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include "ListMyJosephus.h"
#include "Destination.h"

using namespace std;
using namespace std::chrono;

vector<string> splitCSV(const string& line) {
    vector<string> result;
    stringstream ss(line);
    string token;
    while (getline(ss, token, ',')) {
        result.push_back(token);
    }
    return result;
}

vector< vector<string> > loadCSV(const string& filename) {
    vector< vector<string> > csvData;
    ifstream file(filename);
    string line;
    while (getline(file, line)) {
        vector<string> row = splitCSV(line);
        csvData.push_back(row);
    }
    return csvData;
}

int main() {
    srand(time(0));
    
    vector< vector<string> > csvData = loadCSV("destinations.csv");
    if (csvData.empty()) {
        cout << "CSV file not found or empty. Using dummy data." << endl;
        for (int i = 0; i < 25; i++) {
            vector<string> row;
            for (int j = 0; j < 16000; j++) {
                row.push_back("City" + to_string(j));
            }
            csvData.push_back(row);
        }
    }
    
    vector<long long> simulationTimes;
    
    for (int N = 1; N <= 1025; N++) {
        int rowIndex = rand() % csvData.size();
        vector<string> row = csvData[rowIndex];
        
        vector<Destination> destVector;
        unsigned int limit = row.size() < (unsigned int)N ? row.size() : (unsigned int)N;
for (unsigned int i = 0; i < limit; i++) {
    destVector.push_back(Destination(i, row[i]));
}

        
        int M = (N > 1) ? (rand() % (N - 1)) + 1 : 1;
        
        cout << "\nSimulation for N = " << N << ", M = " << M << endl;
        
        ListMyJosephus josephus(M, N);
        josephus.populateDestinations(destVector);
        
        auto start = high_resolution_clock::now();
        
        while (josephus.currentSize() > 1) {
            josephus.eliminateDestination();
        }
        
        auto end = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(end - start).count();
        simulationTimes.push_back(duration);
        
        cout << "Final destination: ";
        Destination finalDest = josephus.getLastRemaining();
        finalDest.printPosition();
        cout << " - ";
        finalDest.printDestinationName();
        cout << endl;
    }
    
    long long totalTime = 0;
    for (auto t : simulationTimes)
        totalTime += t;
    double averageTime = simulationTimes.empty() ? 0 : (double)totalTime / simulationTimes.size();
    cout << "\nAverage simulation time (microseconds) for ListMyJosephus: " << averageTime << endl;
    
    ofstream logFile("results.log");
    if (logFile.is_open()) {
        for (size_t i = 0; i < simulationTimes.size(); i++) {
            logFile << "N = " << i+1 << ": " << simulationTimes[i] << " microseconds" << endl;
        }
        logFile << "Average: " << averageTime << " microseconds" << endl;
        logFile.close();
    } else {
        cout << "Unable to open results.log for writing." << endl;
    }
    
    return 0;
}
