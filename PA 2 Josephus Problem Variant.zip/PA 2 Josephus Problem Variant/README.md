/*******************************************************************************************
* Programmer: Zachary Marseglia
* Class: CptS 223
* Programming Assignment: PA 2 Josephus Problem Variant
* Date: February 10, 2025
* Description: This assignment implements a variant of the Josephus problem where a list of 
* destinations is progressively reduced by eliminating every M-th destination until one remains.
* Two implementations are provided using STL containers: std::list and std::vector. The program 
* reads destination data from a CSV file, simulates the elimination process, and measures the 
* performance of each implementation.
*******************************************************************************************/


1. Does machine processing power affect execution time?
   Yes faster processor can execute more instructions per second, which can give to shorter execution times. But factors like memory speed and system load.

2. Which performs better: std::list or std::vector? Under what conditions?  
   std::vector: Provides fast random access and is cache-friendly. But, erases an element from the middle is costly (O(n)) because it requires shifting elements.  
   std::list: Supports constant-time insertions and deletions from anywhere in the list (O(1)), but traversal is slower due to pointer chasing and lack of cache locality.  
   In our Josephus simulation (which involves repeated deletions), std::list may perform better when deletions are frequent and occur at arbitrary positions. For operations requiring random access or when the dataset is small, std::vector may be preferable.

3. How does N impact runtime compared to M?   
   The runtime is more heavily influenced by N, the number of destinations, because it determines the total number of elimination rounds. Each round involves iterating over several elements. So as N increases, the number of operations grows significantly. In contrast, M (the elimination interval) affects how far you move in each round, but its impact is less pronounced compared to the effect of increasing N.
